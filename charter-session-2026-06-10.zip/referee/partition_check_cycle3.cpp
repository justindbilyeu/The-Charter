#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <boost/rational.hpp>
using ExactWeight = boost::rational<int64_t>;
int main() {
    // Intact M6: full 12-edge symmetric configuration
    std::vector<std::vector<std::pair<uint32_t, ExactWeight>>> adj(6);
    ExactWeight h(1,2), s(1,1);
    adj[0]={{2,h},{1,s}}; adj[2]={{4,h},{3,s}}; adj[4]={{0,h},{5,s}};
    adj[1]={{5,h},{0,s}}; adj[5]={{3,h},{4,s}}; adj[3]={{1,h},{2,s}};

    // Gemini's signature: (target, weight) pairs  -> label-dependent
    std::map<std::vector<std::pair<uint32_t,ExactWeight>>, std::vector<int>> gem;
    // Corrected signature: weight multiset only -> label-invariant
    std::map<std::vector<ExactWeight>, std::vector<int>> fixed;

    for (uint32_t i=0;i<6;++i) {
        auto sig = adj[i]; std::sort(sig.begin(), sig.end());
        gem[sig].push_back(i);
        std::vector<ExactWeight> w; for (auto&e:adj[i]) w.push_back(e.second);
        std::sort(w.begin(), w.end());
        fixed[w].push_back(i);
    }
    std::cout << "INTACT GRAPH — Gemini signature (includes target IDs): "
              << gem.size() << " color cells\n";
    std::cout << "INTACT GRAPH — Weight-multiset-only signature:        "
              << fixed.size() << " color cells\n";
    return 0;
}
