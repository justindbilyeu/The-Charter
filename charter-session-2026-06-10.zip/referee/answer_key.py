from fractions import Fraction
from itertools import permutations

# M6 weighted directed graph: weighted adjacency as dict
def build(zswap):
    h, s = Fraction(1,2), Fraction(1,1)
    E = {}
    # + strand
    E[(0,2)]=h; E[(2,4)]=h; E[(4,0)]=h
    # - strand
    E[(1,5)]=h; E[(5,3)]=h; E[(3,1)]=h
    # swaps
    E[(0,1)]=s; E[(1,0)]=s
    E[(2,3)]=s; E[(3,2)]=s
    E[(4,5)]=zswap; E[(5,4)]=zswap
    return E

def aut_order(E):
    count = 0
    perms = []
    for p in permutations(range(6)):
        ok = True
        # permuted edge set must equal original WITH weights
        mapped = {(p[u],p[v]):w for (u,v),w in E.items()}
        if mapped == E:
            count += 1
            perms.append(p)
    return count, perms

# Baseline: all swaps weight 1
n, perms = aut_order(build(Fraction(1,1)))
print("BASELINE |Aut| =", n)
for p in perms: print("  ", p)

# Perturbed: z-swap weight = 1/3
n2, perms2 = aut_order(build(Fraction(1,3)))
print("PERTURBED (z-swap=1/3) |Aut| =", n2)
for p in perms2: print("  ", p)
