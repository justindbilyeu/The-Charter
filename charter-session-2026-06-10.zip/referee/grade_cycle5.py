from fractions import Fraction
from itertools import permutations

def auts(E):
    out=[]
    for p in permutations(range(6)):
        if {(p[u],p[v]):w for (u,v),w in E.items()} == E:
            out.append(p)
    return out

def perm_order(p):
    n=1
    q=list(p)
    cur=list(p)
    while tuple(cur)!=(0,1,2,3,4,5):
        cur=[p[c] for c in cur]; n+=1
    return n

h,one,third = Fraction(1,2),Fraction(1,1),Fraction(1,3)

# TRUE M6 (cycle 1-3 spec): TWO counter-rotating 3-cycles
def true_m6(zw):
    E={}
    E[(0,2)]=h;E[(2,4)]=h;E[(4,0)]=h
    E[(1,5)]=h;E[(5,3)]=h;E[(3,1)]=h
    E[(0,1)]=one;E[(1,0)]=one;E[(2,3)]=one;E[(3,2)]=one;E[(4,5)]=zw;E[(5,4)]=zw
    return E

# GEMINI CYCLE 5 (from its own fingerprint transcript): ONE 6-cycle
def gemini5(zw):
    E={}
    E[(0,2)]=h;E[(2,4)]=h;E[(4,1)]=h;E[(1,3)]=h;E[(3,5)]=h;E[(5,0)]=h
    E[(0,1)]=one;E[(1,0)]=one;E[(2,3)]=one;E[(3,2)]=one;E[(4,5)]=zw;E[(5,4)]=zw
    return E

print("=== STRAND SUBGRAPH DIFF ===")
print("TRUE M6 strands:  (0->2,2->4,4->0) + (1->5,5->3,3->1)  [TWO 3-cycles]")
print("GEMINI5 strands:  (0->2,2->4,4->1,1->3,3->5,5->0)      [ONE 6-cycle]")

for name, g in [("TRUE M6", true_m6), ("GEMINI5", gemini5)]:
    A = auts(g(one))
    orders = sorted(perm_order(p) for p in A)
    print(f"\n{name} baseline |Aut| = {len(A)}, element orders = {orders}")
    Ap = auts(g(third))
    print(f"{name} perturbed |Aut| = {len(Ap)}")
