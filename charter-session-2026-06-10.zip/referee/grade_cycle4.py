from fractions import Fraction
from itertools import permutations

def aut_order(E):
    return sum(1 for p in permutations(range(6))
               if {(p[u],p[v]):w for (u,v),w in E.items()} == E)

h, one, third = Fraction(1,2), Fraction(1,1), Fraction(1,3)

# THE GRAPH GEMINI ACTUALLY BUILT (from build_m6): self-loops + swaps. NO strand cycles.
def gemini_graph(zw):
    E = {}
    for v in range(6): E[(v,v)] = h          # six self-loops, weight 1/2
    E[(0,1)]=one; E[(1,0)]=one               # x swap
    E[(2,3)]=one; E[(3,2)]=one               # y swap
    E[(4,5)]=zw;  E[(5,4)]=zw                # z swap
    return E

# THE SPECIFIED M6 (sealed exam): counter-rotating strand 3-cycles + swaps
def true_m6(zw):
    E = {}
    E[(0,2)]=h; E[(2,4)]=h; E[(4,0)]=h       # + strand cycle
    E[(1,5)]=h; E[(5,3)]=h; E[(3,1)]=h       # - strand cycle (reversed)
    E[(0,1)]=one; E[(1,0)]=one
    E[(2,3)]=one; E[(3,2)]=one
    E[(4,5)]=zw;  E[(5,4)]=zw
    return E

print("GEMINI'S GRAPH  baseline |Aut| =", aut_order(gemini_graph(one)))
print("GEMINI'S GRAPH  perturbed |Aut| =", aut_order(gemini_graph(third)))
print("TRUE M6         baseline |Aut| =", aut_order(true_m6(one)))
print("TRUE M6         perturbed |Aut| =", aut_order(true_m6(third)))
