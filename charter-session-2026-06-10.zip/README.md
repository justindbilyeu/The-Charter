# Session Bundle — 2026-06-10
**"Same disease, two scales": verification infrastructure for a noisy internet and a noisy lab.**

One day's work, one through-line: confident, internally consistent, wrong artifacts are
the default failure mode of the current information ecosystem — and of AI-augmented
research. Everything in this bundle is a countermeasure.

## Contents

### /triage-machine — Charter Fast Path (v0.1 BENCH)
A claim-routing tool: paste any claim, get a Provenance tier (P1–P4) × Claim-weight
tier (C1–C4) matrix verdict and a USE/HOLD/DISCARD disposition in ~30 seconds.
Routes claims, never validates them. The two-axis P×C split is a working candidate
solution to the Charter's open Q5 (single-axis evidence ladder).
- `triage-machine.jsx` — React artifact (Claude API). KNOWN ISSUE: API bridge fails
  in mobile app; browser test pending ("Create AI-powered artifacts" toggle).
- `README.md` — full spec, deployment roadmap, in-house LLM path (Ollama + RAG).

### /m6-adversarial — Five-Cycle Adversarial Record
Complete record of cycles 1–5 on the M6 fiber prototype (6-node weighted digraph,
automorphism group as validation target). Five distinct failure classes, all caught
by independent runs, none by producer checks. Includes the cycle 5 headline:
a structurally wrong artifact that numerically collided with the sealed key
(Z6 vs S3, both order 6) — the false pass that earned the Threshold Resolution Rule.
- `README.md` — canonical topology, sealed key, cycle-by-cycle record, failure
  taxonomy, cycle 6 directives (open).
- `cycle3-artifact-reproduced.cpp` — Gemini's cycle 3 artifact, independently
  compiled and reproduced (g++ C++17, boost 1.83).

### /charter-v2.8 — Amendments RFC + Validation Experiment
- `AMENDMENTS-RFC.md` — five proposed amendments (Sealed-Key Verification,
  Threshold Resolution, Verbatim Transcripts, Exact-Assertion Gates, Independence
  of Verification), written for adversarial review by the full AI team. Each
  reviewer answers four standing attack questions; approval-only reviews are
  non-responses.
- `CHARTER-AB-01-PROTOCOL.md` — pre-registered A/B experiment measuring the
  Charter's effect on response quality. 5 models × 2 arms × 6 prompts × 2
  replicates, clean-context methodology (fresh profiles, memory off), blind
  rubric grading. COMMIT THIS BEFORE RUNNING ANY TRIALS — pre-registration
  only counts if timestamped first.

### /referee — Grading Infrastructure (published post-grading)
Brute-force answer keys and grading scripts for cycles 4–5. Policy: sealed keys
for OPEN exams never enter the repo; these are published because their cycles
are graded and closed. Cycle 6's acceptance spectrum [1,2,2,2,3,3] is disclosed
by design (collision-resistant); nothing exam-sensitive remains here.
- `answer_key.py` — exhaustive Aut(G) for baseline + perturbed M6 (720 perms).
- `grade_cycle4.py` — proves Gemini's cycle 4 numbers were correct for the wrong graph.
- `grade_cycle5.py` — strand-subgraph diff + element-order spectra (S3 vs Z6).
- `partition_check_cycle3.cpp` — label-dependent vs label-invariant signature comparison.

## Open Items
1. Triage Machine browser test (toggle + Safari/desktop).
2. Cycle 6: Gemini, exact edge-list gate + generator spectra.
3. RFC: route to Kimi first; responses return to Claude for v2.8 synthesis.
4. CHARTER-AB-01: lock P1–P6 verbatim, commit, then run.
5. E8-attractor baby experiment: coarse-graining flows on M6-class constraint
   graphs, measure Aut(K) — tooling already exists in /referee.

## Suggested Commit Message
    Session 2026-06-10: Triage Machine v0.1, M6 cycles 1-5 record,
    Charter v2.8 RFC (5 amendments), CHARTER-AB-01 pre-registration.
    Same disease, two scales.
