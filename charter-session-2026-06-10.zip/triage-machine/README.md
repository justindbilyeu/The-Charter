# TRIAGE MACHINE — Session Archive
**Date:** 2026-06-10 · **Status:** Bench prototype built, runtime blocked, pending browser test
**Origin:** Dead internet theory → "how do we verify what we're reading?"

---

## 1. The Problem

The internet is increasingly noise — generated, recycled, unverifiable content. This is not abstract: Charter/RG/GU research pulls sources from this same internet. Without a verification layer, The Charter is only as good as its inputs. **The verification tool is infrastructure for everything else, not a side project.**

Goal: meet people where they are (phone, paste/voice input) and return a fast, honest routing verdict on any claim — without pretending to validate truth.

## 2. Relationship to the Charter Machine

The Charter FSM (7 states, full G1–G5 gate protocol, multi-AI adversarial review) is the **heavyweight path** — hours per artifact. The Triage Machine is a **fast path**: a stripped-down front end that routes claims in ~30 seconds and never validates them. Validation stays upstream in the full machine. That separation is the firewall that keeps the fast path honest.

**Q5 connection:** Building this forced the split of the single-axis evidence ladder into two axes — provenance (P) and claim weight (C). A peer-reviewed paper can carry a speculative claim; a blog can accurately report settled science. The single ladder couldn't express that; the P×C matrix can. This may be the working solution to the open Q5 structural concern.

## 3. The Fast Path Spec (Triage Machine v0.1)

**States:**
- **S0 INTAKE** — Extract core assertion(s). Split multi-claim input (max 4, most load-bearing).
- **S1 PROVENANCE** — P-tier, based only on evident/stated provenance:
  - P1: Primary source (paper, dataset, direct measurement, official record)
  - P2: Identified secondary (named outlet citing an identifiable primary)
  - P3: Unattributed but plausible (blog, forum, social, no chain of custody)
  - P4: No provenance (generated, circular citation, untraceable)
  - Rule: bare pasted text = P3 at best, P4 if it reads as slop. Never assume a source exists.
- **S2 CLAIM WEIGHT** — C-tier, independent of source:
  - C1: Established / replicated
  - C2: Single-study or conditional result
  - C3: Speculative extrapolation / interpretation beyond evidence
  - C4: Untestable as stated (no threshold, no falsifier)
- **S3 CROSS** — Verdict sentence naming the P×C tension or agreement.
- **S4 DISPOSITION** — three exits:
  - **USE:** P1–P2 × C1–C2, or P3 × C1 (cite the primary instead)
  - **HOLD:** anything C3, or P3 × C2 — full Charter pass required before it feeds real work
  - **DISCARD:** P4 × anything, or C4 × anything — quarantine

**Constitutional rule:** The fast path ROUTES, never VALIDATES. USE ≠ true.

**Usage rule:** Feed it content as encountered in the wild (original framing intact). Do not pose questions to it — it is not a fact-checker.

## 4. Prototype Status

**Built:** React artifact (`triage-machine.jsx`), dark instrument aesthetic, S0–S4 state strip, dual P/C readouts with rationales, 4×4 verdict matrix with the landed cell lit in disposition color, USE/HOLD/DISCARD exit with one actionable guidance line. Calls the Claude API (claude-sonnet-4) with the full protocol embedded in the message; strict-JSON response parsed defensively (fence stripping, brace extraction, raw-body error dumps).

**Blocked:** All runs fail with "Invalid response format" from the API bridge — including a plain-ASCII control test ("test"), ruling out input encoding. Diagnostics instrumented but raw dump not appearing, suggesting the request is rejected at the bridge layer.

**Diagnosis (probable):** The "Create AI-powered artifacts" feature toggle (claude.ai Settings → Profile → Feature preview) may be off, and/or the mobile app's API bridge doesn't support artifact→API calls. Documented reports confirm the toggle is not findable in the iOS app and must be enabled from the web.

**Next action:** (1) Enable toggle at claude.ai/settings/profile from a browser. (2) Re-test artifact in browser (Safari mobile or desktop). If it works in browser but not the app → mobile runtime confirmed as blocker; artifact logic is sound.

**First calibration tests once live:**
1. TikTok water-memory equation with original framing → expect P4×C4 → DISCARD
2. Real claim from LHCb doubly charmed baryon papers → expect P1×C1/C2 → USE
3. Bare equation, zero text → expect intake-note flag (no assertion to route)

## 5. Deployment Roadmap

1. **Bench (now):** Claude artifact — proves tier logic on real claims
2. **Web app:** GitHub Pages + API backend (CarrierCalc pattern)
3. **iOS Share Sheet app:** highlight → Share → Triage → verdict (the "meets people where they are" form)
4. **Browser extension:** right-click triage on desktop

Sequence logic: validate the P/C tier definitions before building distribution. Wrong logic delivered faster is still wrong.

## 6. In-House LLM Path (tabled, on request)

Question: could this run entirely on a home PC with a small local model instead of corporate LLMs?

**Answer: yes, technically.**
- **Ollama** serves a small model (Llama/Qwen/Mistral) as a local API endpoint; the app points at localhost instead of Anthropic.
- **Tailscale** (or similar) lets the phone reach the home PC securely from the field.

**Caveats (Charter-honest):**
- Capability gap: triage is judgment-heavy (P2 vs P3, catching C3 extrapolation). 7–8B local models are measurably worse at this than frontier models. Local verdicts need their own calibration gate before being trusted.
- "Trained on scientific papers" ≠ fine-tuning. The right architecture is **RAG**: stock small model + vector database of vetted papers retrieved at answer time. Cheap, local, and the verified-claims library doubles as the retrieval corpus — solving the corpus problem identified early in this session.

**Realistic in-house stack:** Ollama + small model + vector DB of vetted papers + triage logic. Frontier model for development/calibration; local model for sovereignty once tiers are proven.

**Open item:** hardware spec for the home rig (deferred).

## 7. Open Questions

- Does the P/C matrix produce useful verdicts on messy real-world claims? (Calibration pending runtime fix)
- Does the two-axis split formally resolve Q5, or just relocate it? (Candidate solution, untested)
- Starting corpus domain for the verified-claims library — roofing claims vs. narrow science niche?
- Local model quality threshold: what calibration gate must a 7–8B model pass before its triage verdicts are trusted?
