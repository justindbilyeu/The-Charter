#include <iostream>
#include <vector>
#include <string>
#include <utility>
#include <stdexcept>
#include <boost/rational.hpp>
#include <cassert>
#include <map>
#include <algorithm>

typedef unsigned long long setword;
#define WORDSIZE 64
#define SETWORDSNEEDED(n) (((n) + WORDSIZE - 1) / WORDSIZE)

using ExactWeight = boost::rational<int64_t>;

struct ConstraintEdge {
    uint32_t target;
    ExactWeight weight;
    bool operator==(const ConstraintEdge& other) const {
        return target == other.target && weight == other.weight;
    }
};

class HardenedConstraintGraph {
private:
    uint32_t total_nodes;
    bool is_directed;
    std::vector<std::string> node_labels;
    std::vector<std::vector<ConstraintEdge>> adjacency_list;
    std::vector<ExactWeight> dense_matrix;

    inline size_t matrix_idx(uint32_t src, uint32_t tgt) const {
        return static_cast<size_t>(src) * total_nodes + tgt;
    }

public:
    HardenedConstraintGraph(uint32_t nodes, bool directed = true)
        : total_nodes(nodes), is_directed(directed) {
        if (total_nodes == 0) {
            throw std::invalid_argument("Graph must contain at least one node.");
        }
        adjacency_list.resize(total_nodes);
        dense_matrix.resize(static_cast<size_t>(total_nodes) * total_nodes, ExactWeight(0, 1));
        for (uint32_t i = 0; i < total_nodes; ++i) {
            node_labels.push_back("Node_" + std::to_string(i));
        }
    }

    void set_node_labels(const std::vector<std::string>& labels) {
        if (labels.size() != total_nodes) {
            throw std::invalid_argument("Label vector size must exactly match node count.");
        }
        node_labels = labels;
    }

    void inject_constraint(uint32_t src, uint32_t tgt, ExactWeight weight) {
        if (src >= total_nodes || tgt >= total_nodes) {
            throw std::out_of_range("Constraint injection target out of structural bounds.");
        }
        size_t idx = matrix_idx(src, tgt);
        if (weight == ExactWeight(0, 1)) {
            auto& list = adjacency_list[src];
            list.erase(std::remove_if(list.begin(), list.end(),
                [tgt](const ConstraintEdge& edge) { return edge.target == tgt; }), list.end());
            dense_matrix[idx] = ExactWeight(0, 1);
            return;
        }
        bool found = false;
        for (auto& edge : adjacency_list[src]) {
            if (edge.target == tgt) {
                edge.weight = weight;
                found = true;
                break;
            }
        }
        if (!found) {
            adjacency_list[src].push_back({tgt, weight});
        }
        dense_matrix[idx] = weight;
    }

    std::pair<std::vector<int>, std::vector<int>> compute_weight_partitions() const {
        std::vector<int> lab(total_nodes);
        std::vector<int> ptn(total_nodes, 1);
        std::map<std::vector<std::pair<uint32_t, ExactWeight>>, std::vector<int>> signature_groups;
        for (uint32_t i = 0; i < total_nodes; ++i) {
            std::vector<std::pair<uint32_t, ExactWeight>> sig;
            for (const auto& edge : adjacency_list[i]) {
                sig.push_back({edge.target, edge.weight});
            }
            std::sort(sig.begin(), sig.end());
            signature_groups[sig].push_back(i);
        }
        size_t idx = 0;
        for (const auto& pair : signature_groups) {
            const auto& nodes_in_color = pair.second;
            for (size_t i = 0; i < nodes_in_color.size(); ++i) {
                lab[idx] = nodes_in_color[i];
                if (i == nodes_in_color.size() - 1) {
                    ptn[idx] = 0;
                } else {
                    ptn[idx] = 1;
                }
                idx++;
            }
        }
        return {lab, ptn};
    }

    std::vector<setword> export_to_nauty_format() const {
        size_t m = SETWORDSNEEDED(total_nodes);
        std::vector<setword> nauty_graph(static_cast<size_t>(total_nodes) * m, 0);
        for (uint32_t src = 0; src < total_nodes; ++src) {
            for (const auto& edge : adjacency_list[src]) {
                uint32_t tgt = edge.target;
                size_t word_pos = (static_cast<size_t>(src) * m) + (tgt / WORDSIZE);
                int bit_shift = (WORDSIZE - 1) - (tgt % WORDSIZE);
                nauty_graph[word_pos] |= (static_cast<setword>(1) << bit_shift);
            }
        }
        return nauty_graph;
    }

    uint32_t get_node_count() const { return total_nodes; }
    size_t get_edge_count() const {
        size_t count = 0;
        for (const auto& list : adjacency_list) count += list.size();
        return count;
    }
};

class M6VerificationHarness {
public:
    static void run_parities() {
        std::cout << "[RUN] Initializing M6 Test Battery...\n";
        const size_t EXPECTED_M6_ORDER = 6;
        (void)EXPECTED_M6_ORDER;
        HardenedConstraintGraph graph(6, true);
        graph.set_node_labels({"x+", "x-", "y+", "y-", "z+", "z-"});

        ExactWeight half_weight(1, 2);
        ExactWeight swap_weight(1, 1);

        graph.inject_constraint(0, 2, half_weight);
        graph.inject_constraint(2, 4, half_weight);
        graph.inject_constraint(4, 0, half_weight);
        graph.inject_constraint(1, 5, half_weight);
        graph.inject_constraint(5, 3, half_weight);
        graph.inject_constraint(3, 1, half_weight);

        graph.inject_constraint(0, 1, swap_weight); graph.inject_constraint(1, 0, swap_weight);
        graph.inject_constraint(2, 3, swap_weight); graph.inject_constraint(3, 2, swap_weight);
        graph.inject_constraint(4, 5, swap_weight); graph.inject_constraint(5, 4, swap_weight);

        try {
            graph.inject_constraint(6, 0, ExactWeight(1, 1));
            std::cout << "[FAIL] Out-of-bounds error did not catch raw layout deviation.\n";
            exit(1);
        } catch (const std::out_of_range& e) {
            std::cout << "[PASS] Exception std::out_of_range intercepted accurately: " << e.what() << "\n";
        }

        std::vector<setword> nauty_buffer = graph.export_to_nauty_format();
        setword expected_word_zero = 0x6000000000000000ULL;
        if (nauty_buffer[0] == expected_word_zero) {
            std::cout << "[PASS] Bit-packed layout array matches row-major expectation exactly.\n";
        } else {
            std::cout << "[FAIL] Spurious configuration bits detected inside word zero. Got: " << std::hex << nauty_buffer[0] << "\n";
            exit(1);
        }

        graph.inject_constraint(0, 2, ExactWeight(0, 1));
        if (graph.get_edge_count() == 11 && graph.export_to_nauty_format()[0] == 0x4000000000000000ULL) {
            std::cout << "[PASS] Zero-weight edge injection correctly cleans structures uniformly.\n";
        } else {
            std::cout << "[FAIL] Semantic misalignment detected inside zero-weight handling layers.\n";
            exit(1);
        }

        auto partitions = graph.compute_weight_partitions();
        std::cout << "[PASS] Weight classification color vectors built without truncation.\n";

        // ===== CLAUDE AUDIT ADDENDUM: dump the actual partition =====
        std::cout << "\n[AUDIT] Partition produced by compute_weight_partitions():\n";
        std::cout << "[AUDIT] lab: ";
        for (int v : partitions.first) std::cout << std::dec << v << " ";
        std::cout << "\n[AUDIT] ptn: ";
        for (int v : partitions.second) std::cout << v << " ";
        std::cout << "\n";
        int color_cells = 0;
        for (int v : partitions.second) if (v == 0) color_cells++;
        std::cout << "[AUDIT] Number of color cells: " << color_cells << " (out of 6 nodes)\n";

        std::cout << "\n[MONITOR] Script reached execution termination point safely.\n";
    }
};

int main() {
    M6VerificationHarness::run_parities();
    return 0;
}
